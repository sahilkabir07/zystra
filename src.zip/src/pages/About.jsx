import React from 'react'
import AboutBanner from '../components/aboutComponents/AboutBanner'

const About = () => {
    return (
        <>
            <AboutBanner />
        </>
    )
}

export default About