import React from "react";
import { motion } from "framer-motion";

const AboutBanner = () => {
    return (
        <div className="relative min-h-screen flex items-center justify-center p-4 bg-black">
            <motion.div
                initial={{ opacity: 0, y: 60 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="relative z-20 backdrop-blur-[4px] backdrop-filter bg-white/10 border border-white/20 rounded-2xl shadow-2xl p-6 w-full max-w-6xl min-h-[400px] flex flex-col md:flex-row items-center md:items-start justify-between gap-6 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_8px_rgba(138,43,226,0.3)]"
            >
                {/* 🖼️ Image Area */}
                <div className="w-full md:w-1/2 h-64 md:h-auto rounded-xl overflow-hidden">
                    <img
                        src="https://source.unsplash.com/600x400/?business,teamwork"
                        alt="About us"
                        className="w-full h-full object-cover"
                    />
                </div>

                {/* ✍️ Text Content */}
                <div className="w-full md:w-1/2 flex flex-col justify-center items-start text-left">
                    <motion.h2
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-white to-purple-500 bg-clip-text text-transparent mb-4"
                    >
                        Ready to Elevate Your Digital Presence?
                    </motion.h2>

                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5, duration: 0.7 }}
                        className="text-white/90 text-base md:text-lg mb-6"
                    >
                        Let’s create a custom strategy that fits your business goals. Our
                        team crafts result-driven digital strategies tailored for growth.
                    </motion.p>

                    <motion.button
                        whileHover={{ scale: 1.05 }}
                        transition={{ duration: 0.2 }}
                        className="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-6 py-3 rounded-xl shadow-md font-medium"
                    >
                        Get a Free Consultation
                    </motion.button>
                </div>
            </motion.div>
        </div>
    );
};

export default AboutBanner;
