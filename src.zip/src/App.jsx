import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contacts from "./pages/Contacts";
import Header from "./components/common/Header";
import Footer from "./components/common/Footer";
import GlobalLoader from "./components/common/GlobalLoader";

const App = () => {
  const [showLoader, setShowLoader] = useState(true);

  useEffect(() => {
    const alreadyShown = sessionStorage.getItem("initialLoaderShown");

    if (alreadyShown) {
      setShowLoader(false);
    } else {
      sessionStorage.setItem("initialLoaderShown", "true");

      // Show loader for 2.5s then hide
      const timer = setTimeout(() => {
        setShowLoader(false);
      }, 2500);

      return () => clearTimeout(timer);
    }
  }, []);

  if (showLoader) {
    return <GlobalLoader />; // SHOW LOADER ALONE
  }

  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contacts />} />
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
